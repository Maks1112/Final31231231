﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kassa.Bl;
namespace Kassa
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MessageService mss = new MessageService();
            MainForm form=new MainForm();
            Manager m=new Manager();
            MainPresenter pres = new MainPresenter(form, m,mss);
            Application.Run(form);
        }
    }
}
