﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace Kassa.Bl
{
  public   interface IManeger
  {
      void SerializeToFile(List<Train> trains, string fname);
      List<Train> DeSerializeFile(string fname);
      
      event EventHandler ExceptionEvent;
  }
   public  class Manager:IManeger
    {
      
       public void SerializeToFile (List<Train> trains,string fname)
       {
          
           try
           {
               using (FileStream fs = new FileStream(fname, FileMode.Create, FileAccess.ReadWrite))
               {
                   BinaryFormatter bf = new BinaryFormatter();
                   bf.Serialize(fs, trains);
               }
           }
           catch(Exception e)
           {
               if (ExceptionEvent!=null)
               {
                   ExceptionEvent.Invoke(e, EventArgs.Empty);
               }
               
           }
          
       }

       public List<Train> DeSerializeFile(string fname)
       {

           try
           {
               using (FileStream fs = new FileStream(fname, FileMode.Open, FileAccess.Read))
               {
                   BinaryFormatter bf = new BinaryFormatter();
                List<Train> trains=(List<Train>)bf.Deserialize(fs);
                   return trains;
               }
           }
           catch (Exception e)
           {
               if (ExceptionEvent != null)
               {
                   ExceptionEvent.Invoke(e, EventArgs.Empty);
               }
               return null;
           }
       }

       public event EventHandler ExceptionEvent;
    }

    [Serializable]
   public struct Train
    {
        private int _numerPoezda;
        private DateTime _data;
        private int _kolMest;
        private string name;
        public Train(int n,DateTime dt,int mesta,string name)
        {
            this._numerPoezda = n;
            this._data = dt;
            this._kolMest = mesta;
            this.name = name;
        }

        public string Name
        {
            get { return name; }
        }

        public int KolichestvoMest
        {
            get { return _kolMest; }
            set { _kolMest = value; }
        }

        public int NomerPoezda
        {
            get { return _numerPoezda; }
        }

        public DateTime DataOtpravleniya
        {
            get { return _data; }
        }
    }


    
}
